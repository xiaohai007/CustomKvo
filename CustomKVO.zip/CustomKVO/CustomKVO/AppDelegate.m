//
//  AppDelegate.m
//  CustomKVO
//
//  Created by yulong Yang on 2020/10/30.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    return YES;
}



@end
