//
//  NSObject+XHKVO.h
//  CustomKVO
//
//  Created by yulong Yang on 2020/10/30.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^XHKVOBlock)(id observer,NSString *keyPath,id oldValue,id newValue);

@interface NSObject (XHKVO)
- (void)lg_addObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath block:(XHKVOBlock)block;

- (void)lg_removeObserver:(NSObject *)observer forKeyPath:(NSString *)keyPath;
@end

NS_ASSUME_NONNULL_END
