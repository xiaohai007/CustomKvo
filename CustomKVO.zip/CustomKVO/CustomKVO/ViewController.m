//
//  ViewController.m
//  CustomKVO
//
//  Created by yulong Yang on 2020/10/30.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import "ViewController.h"
#import "XHViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}

@end
