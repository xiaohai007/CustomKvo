//
//  XHPerson.h
//  CustomKVO
//
//  Created by yulong Yang on 2020/10/30.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XHPerson : NSObject{
    @public
    NSString *name;
}
@property (nonatomic, copy) NSString *nickName;

//+ (instancetype)shareInstance;
@end

NS_ASSUME_NONNULL_END
