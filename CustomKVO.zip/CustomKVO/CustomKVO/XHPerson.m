//
//  XHPerson.m
//  CustomKVO
//
//  Created by yulong Yang on 2020/10/30.
//  Copyright © 2020 yulong Yang. All rights reserved.
//

#import "XHPerson.h"

@implementation XHPerson
static XHPerson *_instance = nil;

//+ (instancetype)shareInstance{
//    static dispatch_once_t onceToken ;
//    dispatch_once(&onceToken, ^{
//        _instance = [[super allocWithZone:NULL] init] ;
//    }) ;
//    return _instance ;
//}
//
//+(id)allocWithZone:(struct _NSZone *)zone{
//    return [XHPerson shareInstance] ;
//}
//
//-(id)copyWithZone:(struct _NSZone *)zone{
//    return [XHPerson shareInstance] ;
//}
//
//- (void)setNickName:(NSString *)nickName{
//    NSLog(@"来到 XHPerson 的setter方法 :%@",nickName);
//    _nickName = nickName;
//}
- (void)dealloc
{
    NSLog(@"person dealloc---");
}
@end
